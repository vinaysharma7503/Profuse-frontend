import SignupReducer from './signupReducer'

export default {
    SignupReducer
}