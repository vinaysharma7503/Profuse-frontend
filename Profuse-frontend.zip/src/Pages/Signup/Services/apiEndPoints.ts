export default {
    SIGNUP: '/web/auth/register'
}