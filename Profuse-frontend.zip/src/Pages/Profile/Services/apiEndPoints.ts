export default {
    USERPROFILE: '/web/auth/get-user-profile',
    UPDATEUSERPROFILE: '/web/auth/update-user-profile',
    ADDFUNDS:'/web/account/deposit-fund',
    WITHDRAWFUNDS:'/web/account/withdraw-fund'
}