import LoginReducer from './loginReducer'

export default {
    LoginReducer
}