export default {
    LOGIN: '/web/auth/login'
}