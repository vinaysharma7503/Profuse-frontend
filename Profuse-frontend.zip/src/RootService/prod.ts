export default {
    BASEURL:'',
}