export default {
    BASEURL:'http://localhost:8000/api/v1',
}